import React from "react";
import DecisionTree from "./Component/DecisionTree";
import UserFlow from "./Component/UserFlow";
 
function App() {
  return (
    <div style={{ padding: "20px" }}>
    
      {/* <DecisionTree  /> */}
      <UserFlow />
    
    </div>
  );
}
 
export default App;
